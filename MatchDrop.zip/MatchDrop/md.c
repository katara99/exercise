#include "mydefs.h"

bool is_final_board(board *b);
void generate_children(state *s, int parent_index);
bool is_duplicate(state *s, board *b);
void copy_board(board *dest, board *src);
void print_board(board *b);

bool file2str(const char* fname, char* str)
{
    if (fname == NULL || str == NULL) {
        return false;
    }
    FILE *fp = fopen(fname, "r");
    if (fp == NULL) {
        return false;
    }

    char line[BRDSZ + 2]; // 加2是为了换行符和字符串结束符
    int line_count = 0;
    char *p = str;
    bool hawk_read = false;
    int width = -1;

    while (fgets(line, sizeof(line), fp) != NULL) {
        // 移除换行符
        size_t len = strlen(line);
        if (line[len - 1] == '\n') {
            line[len - 1] = '\0';
            len--;
        }
        if (len == 0) {
            continue; // 跳过空行
        }

        if (!hawk_read) {
            // 第一行应该是鹰牌
            if (len != 1 || !isupper(line[0])) {
                fclose(fp);
                return false;
            }
            *p++ = line[0];
            hawk_read = true;
        } else {
            // 后续行是棋盘的行
            if (len > BRDSZ) {
                fclose(fp);
                return false;
            }
            // 所有字符必须是大写字母
            for (size_t i = 0; i < len; i++) {
                if (!isupper(line[i])) {
                    fclose(fp);
                    return false;
                }
            }
            // 检查所有行的长度是否相同
            if (width == -1) {
                width = len;
            } else if ((int)len != width) {
                fclose(fp);
                return false;
            }
            *p++ = '-';
            strcpy(p, line);
            p += len;
            line_count++;
            if (line_count > BRDSZ) {
                fclose(fp);
                return false;
            }
        }
    }
    fclose(fp);

    if (!hawk_read || line_count == 0) {
        return false;
    }
    *p = '\0';
    return true;
}

state* str2state(const char* str)
{
   if (str == NULL) {
        return NULL;
    }
    // 分配状态空间
    state *s = (state*)malloc(sizeof(state));
    if (s == NULL) {
        return NULL;
    }
    s->board_count = 0;
    // 初始化第一个棋盘
    board *b = &s->boards[s->board_count++];
    b->parent_index = -1;
    b->moves = 0;
    memset(b->completed_columns, 0, sizeof(b->completed_columns));

    // 解析字符串
    char *token;
    char temp_str[MAXSTR];
    strncpy(temp_str, str, MAXSTR);
    temp_str[MAXSTR - 1] = '\0'; // 确保字符串以空字符结束
    token = strtok(temp_str, "-");
    if (token == NULL || strlen(token) != 1 || !isupper(token[0])) {
        free(s);
        return NULL;
    }
    b->hawk = token[0];
    int row = 0;
    int width = -1;
    while ((token = strtok(NULL, "-")) != NULL) {
        int len = strlen(token);
        if (len > BRDSZ || row >= BRDSZ) {
            free(s);
            return NULL;
        }
        if (width == -1) {
            width = len;
        } else if (len != width) {
            free(s);
            return NULL;
        }
        for (int col = 0; col < len; col++) {
            if (!isupper(token[col])) {
                free(s);
                return NULL;
            }
            b->tiles[row][col] = token[col];
        }
        row++;
    }
    if (row == 0) {
        free(s);
        return NULL;
    }
    b->height = row;
    b->width = width;

    return s;
}

int solve(state* s, bool verbose)
{
   if (s == NULL) {
        return -1;
    }
    int f = 0;
    while (f < s->board_count) {
        board *current = &s->boards[f];
        // 检查当前棋盘是否为最终状态
        if (is_final_board(current)) {
            // 重构路径
            if (verbose) {
                int path[MAXBRDS];
                int path_len = 0;
                int idx = f;
                while (idx != -1) {
                    path[path_len++] = idx;
                    idx = s->boards[idx].parent_index;
                }
                for (int i = path_len - 1; i >= 0; i--) {
                    print_board(&s->boards[path[i]]);
                }
            }
            return current->moves;
        }
        // 生成子节点
        generate_children(s, f);
        f++;
    }
    // 未找到解决方案
    return -1;
}



bool is_final_board(board *b)
{
    for (int col = 0; col < b->width; col++) {
        char ch = b->tiles[0][col];
        for (int row = 1; row < b->height; row++) {
            if (b->tiles[row][col] != ch) {
                return false;
            }
        }
    }
    return true;
}

void generate_children(state *s, int parent_index)
{
    board *parent = &s->boards[parent_index];
    for (int col = 0; col < parent->width; col++) {
        if (parent->completed_columns[col]) {
            continue;
        }
        if (s->board_count >= MAXBRDS) {
            fprintf(stderr, "棋盘列表已满\n");
            exit(1);
        }
        board *child = &s->boards[s->board_count];
        copy_board(child, parent);
        // 将鹰牌移入列中
        char new_hawk = child->tiles[child->height - 1][col];
        for (int row = child->height - 1; row > 0; row--) {
            child->tiles[row][col] = child->tiles[row - 1][col];
        }
        child->tiles[0][col] = parent->hawk;
        child->hawk = new_hawk;
        child->parent_index = parent_index;
        child->moves = parent->moves + 1;
        // 检查列是否已完成
        char ch = child->tiles[0][col];
        bool completed = true;
        for (int row = 1; row < child->height; row++) {
            if (child->tiles[row][col] != ch) {
                completed = false;
                break;
            }
        }
        if (completed) {
            child->completed_columns[col] = 1;
        } else {
            child->completed_columns[col] = parent->completed_columns[col];
        }
        // 检查是否有重复
        if (!is_duplicate(s, child)) {
            s->board_count++;
        }
    }
}

bool is_duplicate(state *s, board *b)
{
    for (int i = 0; i < s->board_count; i++) {
        board *b2 = &s->boards[i];
        if (b->hawk != b2->hawk) {
            continue;
        }
        if (memcmp(b->tiles, b2->tiles, sizeof(b->tiles)) == 0 &&
            memcmp(b->completed_columns, b2->completed_columns, sizeof(b->completed_columns)) == 0) {
            return true;
        }
    }
    return false;
}

void copy_board(board *dest, board *src)
{
    memcpy(dest, src, sizeof(board));
}

void print_board(board *b)
{
    printf("%c\n", b->hawk);
    for (int row = 0; row < b->height; row++) {
        for (int col = 0; col < b->width; col++) {
            printf("%c", b->tiles[row][col]);
        }
        printf("\n");
    }
}

void test(void)
{
    // 您可以在此处添加测试代码
}

